
To build the C and C++ samples, first edit the c_sampleBuild.sh and linkSample.sh scripts and set the "-L" option's path for the system libraries.

Please see http://www.chilkatsoft.com/downloads_mingw.asp for more information.