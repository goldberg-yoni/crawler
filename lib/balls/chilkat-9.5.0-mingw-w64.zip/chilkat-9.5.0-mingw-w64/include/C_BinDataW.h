// This is a generated source file for Chilkat version 9.5.0.51
#if defined(WIN32) || defined(WINCE)

#ifndef _C_BinDataWH
#define _C_BinDataWH
#include "chilkatDefs.h"

#include "Chilkat_C.h"

CK_VISIBLE_PUBLIC HBinDataW BinDataW_Create(void);
CK_VISIBLE_PUBLIC void BinDataW_Dispose(HBinDataW handle);
#endif

#endif // WIN32 (entire file)
