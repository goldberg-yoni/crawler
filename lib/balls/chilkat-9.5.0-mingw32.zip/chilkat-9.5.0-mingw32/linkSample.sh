
g++ -Wl,--enable-auto-import linkSample.cpp -o"linkSample.exe" -L. -lchilkat-9.5.0 -L/c/MinGW/lib -lcrypt32 -lws2_32 -ldnsapi

